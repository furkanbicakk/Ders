/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sıinavlar;
import java.util.Scanner;
/**
 *
 * @author PCLAB1-46
 */
public class Sıinavlar {
 
     
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner oku=new Scanner(System.in);
        System.out.println("sayı 1. gir");
    int sayi1=oku.nextInt();
      System.out.println("sayı 2. gir");
      int sayi2=oku.nextInt();
        System.out.println("sayı 3. gir");
       int sayi3=oku.nextInt();
       if(sayi1>sayi2&&sayi1>sayi3){
        if(sayi2>sayi3){
            System.out.println(sayi1+">"+sayi2+">"+sayi3);
        }else{
            System.out.println(sayi1+">"+sayi3+">"+sayi2);
        }
       }else if(sayi2>sayi1&&sayi2>sayi3){
        if(sayi1>sayi3){
            System.out.println(sayi2+">"+sayi1+">"+sayi3);
        }else{
            System.out.println(sayi2+">"+sayi3+">"+sayi1);
        }
       }else if(sayi3>sayi1&&sayi3>sayi2){
        if(sayi1>sayi2){
            System.out.println(sayi3+">"+sayi1+">"+sayi2);
        }else{
            System.out.println(sayi3+">"+sayi2+">"+sayi1);
        }
       }if(sayi3==sayi1&&sayi3==sayi2){
        System.out.println("Birbirine eşit");
       }
    }
    
}
