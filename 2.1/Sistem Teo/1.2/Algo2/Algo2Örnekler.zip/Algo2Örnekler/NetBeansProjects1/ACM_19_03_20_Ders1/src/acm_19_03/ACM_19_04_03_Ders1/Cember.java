package acm_19_03.ACM_19_04_03_Ders1;
public class Cember {
    double yariCap= 1.0;
    
    public Cember(){
        
    }
    
    public Cember(double yeniYaricap){
        yariCap= yeniYaricap;
    }
    public Cember(int yeniYaricap){
        yariCap= yeniYaricap;
    }
    public double alan(){
        return Math.PI*yariCap*yariCap;
    }
    public void ciz(){
        System.out.println(".");
        for (int i = 0; i < (int)yariCap; i++) {
            
        }
    }
}
