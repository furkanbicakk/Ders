
package algo1vize;

import java.util.Scanner;

public class Algo1vize {

    public boolean esitmi(){
    Scanner k=new Scanner(System.in);
    int sayi=k.nextInt(); int sayac=0;
    for(int i=0; i<9;i++){
    int yeni=k.nextInt();
    if(sayi==yeni) sayac++;     
    }
    if(sayac==9) return true;
    else return false;
    }
    
    
    public void yaz(){
    Scanner k=new Scanner (System.in);
    int sayac;
    for(sayac=20; sayac>0; sayac--){
    String s=k.nextLine();
    if(s.length()>=5){
        System.out.println(s);
    } 
    sayac++;
    } }
    public void sirala(){
        Scanner k=new Scanner(System.in);
        System.out.println("Üç tane sayi giriniz:");
        int a, b,c;
        a=k.nextInt(); b=k.nextInt(); c=k.nextInt();
        if(a<b && b<c)System.out.println(a+"<"+b+"<"+c);
        else if(a<c && c<b)System.out.println(a+"<"+c+"<"+b);
        else if(b<a && a<c)System.out.println(b+"<"+a+"<"+c);
        else if(b<c && c<a)System.out.println(b+"<"+c+"<"+a);
        else if(c<a && a<b)System.out.println(c+"<"+a+"<"+b);
        else if(c<b && b<a)System.out.println(c+"<"+b+"<"+a);
        else System.out.println(a+"="+b+"="+c);
    }
 public void topla(){
 int m,n, toplam=0;
 for(m=1;m<=3;m++){
    for(n=2; n<=4; n++)
        toplam+=m+n+3;
 }
     System.out.println(toplam);
 }
    
    public static void main(String[] args) {
        Algo1vize a=new Algo1vize();
       // System.out.println(a.esitmi());
        //a.yaz();
        a.topla();
    }
    
}
