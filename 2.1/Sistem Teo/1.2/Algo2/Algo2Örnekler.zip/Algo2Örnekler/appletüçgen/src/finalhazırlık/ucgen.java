package finalhazırlık;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;

public class ucgen extends Applet{
    
    public void init()
    {
        setSize(500,500);
        setBackground(Color.MAGENTA);
    }

    public void paint(Graphics g)
    {
        g.drawLine(250,250,250,300);
        g.drawLine(250,250,300,300);
        g.drawLine(250,300,300,300);
    }
 
 
    
}
