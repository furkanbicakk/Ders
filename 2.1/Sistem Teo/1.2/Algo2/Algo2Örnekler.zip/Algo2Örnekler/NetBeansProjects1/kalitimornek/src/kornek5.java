class karematris{
    int sstun;double [][] mat;
    karematris(int sstun){
        mat=new double[sstun][sstun];
        for (int i = 0; i < mat.length; i++) 
            for (int j = 0; j < mat[i].length; j++) 
                mat[i][j]=(int)(Math.random()*15);                }
public String toString(){
String S="";
    for (int i = 0; i < mat.length; i++) {
        for (int j = 0; j < mat[i].length; j++) 
            S=S+mat[i][j]+"\t";
        S=S+"\n";
    }
    return S;}}
class ucgenmatris extends karematris{
    boolean ust;
    ucgenmatris(boolean ust,int sutun){
        super(sutun);
        this.ust=ust;
        if(ust){
            for (int i = 0; i < mat.length; i++) 
                for (int j = i+1; j < mat[i].length; j++) 
                    mat[i][j]=0.0;                }
        else {for (int i = 0; i < mat.length; i++) 
                for (int j = 0; j < i; j++) 
                    mat[i][j]=0.0;        }}
    public String toString(){
        return "Ucgen matris:\n"+super.toString();
    }
}
    public class kornek5 {
        public static void goster(karematris km){
            System.out.println(km.toString());
        }
        public static void main(String[] args) {
            karematris km=new karematris(6);  goster(km);
            ucgenmatris um=new ucgenmatris(true, 5); goster(um);            
        }
    }
