
package thread_ornekler;

public class YieldOrnek extends Thread {
    public void run()
    { 
        for (int i = 0; i < 5; i++) {
            System.out.println(this.getName()+"<->"+i);
            Thread.yield();
            //this.yield();
        }
    }
    public static void main(String[] args) {
        YieldOrnek y1=new YieldOrnek();
        YieldOrnek y2=new YieldOrnek();
        YieldOrnek y3=new YieldOrnek();
        y1.start();
        y2.start();
        y3.start();
    }
}
