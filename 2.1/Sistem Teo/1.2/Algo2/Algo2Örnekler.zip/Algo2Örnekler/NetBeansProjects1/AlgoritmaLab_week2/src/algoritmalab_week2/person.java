
package algoritmalab_week2;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;
public class person {
    public String firstName;
    public String lastName;
    public Calendar birthday;
    //public person()
    //public person(int ...)
    
    public person(String firstName, String lastName){
         this.firstName = firstName;
        this.lastName = lastName;
        this.birthday = new GregorianCalendar();
    }
    public String fullName()
    {
        return firstName + " " + lastName;
    } 
    public int age(Calendar today)
    {
        return today.get(Calendar.YEAR) - birthday.get(Calendar.YEAR);
    }
    public static void main(String[] args) {
        person john = new person("ali","aksoy");
        System.out.println(john.fullName());
        System.out.println(john.age(new GregorianCalendar(1988,1,5)));
}
}
