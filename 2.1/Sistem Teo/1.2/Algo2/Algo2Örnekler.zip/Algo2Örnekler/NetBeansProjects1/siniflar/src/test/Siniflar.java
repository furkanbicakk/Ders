package test;
class cember{
    double r;
    cember(){   r=1.0; }
    cember(double nr){r=nr;}
    double alanHesap(){return Math.PI*r*r;}
    double cevreHesap(){return 2*Math.PI*r;}
}
public class Siniflar {
    public static void main(String[] args) {
        cember c1=new cember(2.7);
        System.out.println(c1.r+" yarıçaplı çemberin alanı:"+
                c1.alanHesap()+" çevresi:"+c1.cevreHesap());
        c1.r=3.8;
        System.out.println(c1.r+" yarıçaplı çemberin alanı:"+
                c1.alanHesap()+" çevresi:"+c1.cevreHesap());
    }
    
}
