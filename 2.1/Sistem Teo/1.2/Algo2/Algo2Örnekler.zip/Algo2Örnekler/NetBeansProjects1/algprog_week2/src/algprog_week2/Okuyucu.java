
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class Okuyucu {
    //adresi parametre olarak verilen dosyadaki alt alta yazılmış sayıların
    //ortalamasını, toplamını, en büyük ve en küçük değerlerini bulup ekrana yazdırın
    public void intOku(String path) {
        try {
            Scanner s = new Scanner(new File(path));
            int enbuyuk = 0;
            int enkucuk = 9999;
            double toplam = 0;
            double ortalama = 0;
            int satirsayac = 0;
            while (s.hasNext()) {
                satirsayac++;
                int a = s.nextInt();
                if (a > enbuyuk) {
                    enbuyuk = a;
                }
                if (a < enkucuk) {
                    enkucuk = a;
                }
                toplam += a;
            }
            ortalama = toplam / satirsayac;
            System.out.println(
                    "RAKAM SAYISI = " + satirsayac
                    + "\nEN BUYUK     = " + enbuyuk
                    + "\nEN KUCUK     = " + enkucuk
                    + "\nTOPLAM       = " + toplam
                    + "\nORTALAMA     = " + ortalama);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //dosyadaki sayıların tek ve çift olanlarının ayrı ayrı kaç tane olduğunu 
    // ve toplamlarını bulun
    public void tekCıft(String path) {
        try {
            Scanner s = new Scanner(new File(path));
            int tektoplam = 0;
            int cifttoplam = 0;
            int teksayac = 0;
            int ciftsayac = 0;
            while (s.hasNext()) {
                int a = s.nextInt();
                if (a % 2 == 0) {
                    ciftsayac++;
                    cifttoplam += a;
                } else {
                    teksayac++;
                    tektoplam += a;
                }
            }
            System.out.println(
                    "TEK SAYI ADEDI  = " + teksayac
                    + "\nCIFT SAYI ADEDI = " + ciftsayac
                    + "\nTEK SAYILARIN TOPLAMI     = " + tektoplam
                    + "\nCIFT SAYILARIN TOPLAMI    = " + cifttoplam);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //bir dosyadaki yazının tamamını kelime kelime okuyup bunları ekrana yazdırın
    public void kelimeleriOku(String path) {
        try {
            Scanner s = new Scanner(new File(path));
            while (s.hasNext()) {
                String kelime = s.next();
                System.out.println(kelime);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // dosyanın her satırında tab karakterleriyle ayrılmış ad ve soyad bilgileri vardır. 
    // Bunları ekrana "Ad = ali Soyad = Demir" şeklinde yazdırın
    public void adSoyadOku(String path) {
        try {
            Scanner s = new Scanner(new File(path));
            while (s.hasNextLine()) {
                String satir = s.nextLine();
                String[] tokens = satir.split("\t");
                String ad = tokens[0];
                String soyad = tokens[1];

                System.out.println("Ad = " + ad + "\t Soyad= " + soyad);
            }
        } catch (Exception e) {
        }
    }
    //Bir dosyadaki isimleri okuyan ve bunları başharflerine göre dosyalara yazan program
    public void ilkHarfineGoreYaz(String path) {
        try {
            Scanner s = new Scanner(new File(path));
            while (s.hasNext()) {
                String st = s.next().toLowerCase();
                char a = st.charAt(0);
                FileWriter fw = new FileWriter("/temp/" + a + ".txt", true); //true, dosyaya append işlemi yapıyor
                fw.write(st + "\n");
                fw.flush();
                fw.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //dosyadaki isimlerden parametre olarak gelen harf ile başlayanları ekrana yazdır
    public void ilkHarf(String path, char c) {
        try {
            Scanner s = new Scanner(new File(path));
            while (s.hasNext()) {
                String st = s.next().toLowerCase();
                if (st.charAt(0) == c) {
                    System.out.println(st);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//bir dosyada öğrenci no;ad;soyad şeklinde veriler vardır.
//bunları ad=Ali, soyad=Demir, Öğrenci No=123
//şeklinde ekrana yazdır
    public void adSoyadNo(String path) {
        try {
            Scanner s = new Scanner(new File(path));
            while (s.hasNextLine()) {
                String satir = s.nextLine();
                String[] tokens = satir.split(";");
                String ad = tokens[1];
                String soyad = tokens[2];
                String no = tokens[0];

                System.out.println("Ad = " + ad + "\t Soyad = " + soyad + "\tÖğrenci No = " + no);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        Okuyucu o = new Okuyucu();
  //      o.kelimeleriOku("D:\\50isim.txt");
       //o.adSoyadOku("D:\\50isim.txt");
        o.intOku("C:\\Users\\PCLAB1-46\\Desktop\\sayilar.txt");
 //      o.tekCıft("D:\\tekcift.txt");
    }
}
