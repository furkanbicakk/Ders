/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algprog_week1;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author betul
 */
public class person2 {
    public String firstName;
    public String lastName;
    public Calendar birthday;
    public person2(String firstName, String lastName)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthday = new GregorianCalendar();
}
    public String fullName()
    {
        return firstName + " " + lastName;
    }
    
    public int age(Calendar today)
    {
        return today.get(Calendar.YEAR) - birthday.get(Calendar.YEAR);
    }
    public static void main(String[] args) {
    person2 p1=new person2("ali","aksoy");
        System.out.println("isim-soyisim = " + p1.fullName());
        System.out.println("yaş="+p1.age(new GregorianCalendar(1988,1,5)));
    }
}
