/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Scanner;

class yamuk {

    int taban;
    int tavan;
    int yukseklik;

    /* Parametresiz Kurucu Fonksiyon */
    public yamuk() {

    }

    /* Parametreli Kurucu Fonksiyon */
    public yamuk(int gelenTavan, int gelenTaban, int gelenYukseklik) {

        this.taban = gelenTaban;
        this.tavan = gelenTavan;
        this.yukseklik = gelenYukseklik;

    }

    /* Yamuğun alanını hesaplayan fonksiyon */
    public double alanHesapla() {

        return ((taban + tavan) * yukseklik) / 2;

    }

}

class dikdortgen2 {

    int en;
    int boy;
    int yukseklik;

    public dikdortgen2() {
    }

    public double hacimHesapla() {
        return (this.boy * this.en * this.yukseklik);

    }

}

public class Dortgen {

    public static void main(String[] args) {
        yamuk y1 = new yamuk(); // Parametresiz kurucudan
        yamuk y2 = new yamuk(12, 14, 13); // Parametreli kurucudan

        System.out.printf("Parametresiz kurucu nesnesinin alanı: %f", y1.alanHesapla());
        System.out.print("\n");
        System.out.printf("Parametreli kurucu nesnesinin alanı: %f", y2.alanHesapla());
        System.out.print("\n");

        dikdortgen2 d1 = new dikdortgen2();

        Scanner veriAl = new Scanner(System.in);
        System.out.print("Dikdörtgen en :");
        d1.en = veriAl.nextInt();
        System.out.print("Dikdörtgen boy :");
        d1.boy = veriAl.nextInt();
        System.out.print("Dikdörtgen yükseklik :");
        d1.yukseklik = veriAl.nextInt();

        System.out.println("Dikdörtgenin hacmi : "+ d1.hacimHesapla());
       

    }

}
