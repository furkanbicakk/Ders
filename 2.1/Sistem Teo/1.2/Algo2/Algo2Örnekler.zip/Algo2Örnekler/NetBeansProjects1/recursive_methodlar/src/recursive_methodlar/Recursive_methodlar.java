
package recursive_methodlar;

public class Recursive_methodlar {
public static int max(int A[],int max,int i){
    if(i>=A.length) return max;
    if(max<A[i]) max=A[i];
    return max(A,max, ++i);
}
public static void bul(char A[], char B[], int i){
    if(i>=A.length) System.exit(1);
    if(A[i]==B[i]) System.out.println(A[i]);
    bul(A, B, ++i);
}
public static int topla(int t, int i){
    if(i>103) return t;
    t=t+i;
    i=i+2;
    return topla(t,i);
}
public static void yaz(String S[], int i){
    if(i>=S.length) System.exit(1);
    if(S[i].length()==5) System.out.println(S[i]);
    yaz(S,++i);
}
    public static void main(String[] args) {
       // int A[]={5,6,9,3,4};
        //System.out.println(max(A, A[0],1));
        char A[]={'a','b','c'};
        char B[]={'a','d','s'};
       // bul(A,B,0);
        String S[]={"gfcjg","uhy","ytgku"};
        //System.out.println(topla(0,1));
        yaz(S,0);
    }
    
}
