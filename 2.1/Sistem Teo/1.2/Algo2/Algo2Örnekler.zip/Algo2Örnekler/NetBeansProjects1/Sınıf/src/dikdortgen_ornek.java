/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class dikdortgen_sinif{
    double en,boy;
    dikdortgen_sinif(){        
        this.en=1;this.boy=1;
    }
    dikdortgen_sinif(double en,double boy)
    {        
        this.en=en; this.boy=boy;
    }
    double çevreHesapla(){  return (en+boy)*2;  }
    double alan_HEsapla(){  return en*boy;   }
}
public class dikdortgen_ornek {
    public static void main(String[] args) {
        dikdortgen_sinif ornek_diskdortgen = new dikdortgen_sinif();
        double çevre = ornek_diskdortgen.çevreHesapla();
        double alan = ornek_diskdortgen.alan_HEsapla();
        
        System.out.println("alan = " + alan+ "çevre=" +çevre);
        
        dikdortgen_sinif ornek2 = new dikdortgen_sinif(5.2,6.4);
        çevre = ornek2.çevreHesapla();
        alan = ornek2.alan_HEsapla();
        
        System.out.println("alan = " + alan+ "çevre=" +çevre);
    }
    
}
