package buyukkuculcember;

import java.applet.Applet;
import java.awt.Graphics;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BUYUKKUCULCEMBER extends Applet{
    
    int a = 210;
    int b = 80;
    int secim=1;
    
    public void init()
    {
        setSize(500, 500);
    }
    
    public void update()
    {
        
        if (secim==1) //küçültme
        {
            a++;
            b-=2;
            if (b==10) 
            {
                secim = 2;
            }
        }
    
        if (secim==2) //büyütme
        {
            a--;
            b+=2;
            if (b==80) 
            {
            secim=1;
            }
        }
    
            try { Thread.sleep(15); } 
            catch (Exception ex) { }
        
            repaint();
            
    }

public void paint(Graphics g){

    g.drawOval(a, a, b, b); 
    update();

  
/*
    g.drawRect(a, a, b, b); // büyüyüp küçülen kare
    update();
*/
 
   


}
    
}
