package sonçalışma2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Sonçalışma2 {

    
    public static void main(String[] args) throws FileNotFoundException {
       
        File not = new File("ali.txt");
        File sonuc = new File("veli.txt");
        Scanner oku = new Scanner(not);
        PrintWriter pw = new PrintWriter(sonuc);
        
        int syc = 0;
        double toplam = 0;
        
        while (oku.hasNext()) 
        {
            
            
            String satır = oku.next();
            String dizi [] = satır.split(" ");
            
            String ad = dizi[0] + " " + dizi[1];
            
            int v = Integer.parseInt(dizi[2]);
            int f = Integer.parseInt(dizi[3]);
            
            double s = v*0.4 + f*0.6;
            
            syc++;
            
            toplam+=s;
            
            pw.println(ad+" "+ v + " " + f + " " + s);
      
        }
        
        pw.close();
        
    }
    
}
