/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursivefonksiyonlar;

/**
 *
 * @author PCLAB1-46
 */
public class NewMain {
    public static void main(String[] args) {
        String kelime="aaaba";
        System.out.println(recursive(kelime,0,kelime.length()-1));
    }
    
    public static boolean recursive(String kelime, int i, int j) {
        System.out.println(i+" "+j);
        
        if(j>i) {
            if(kelime.charAt(i) == kelime.charAt(j)){
                return recursive(kelime, i+1,  j-1);
            }else{
                return false;
            }
        }
        return true;
    } 
    
}
