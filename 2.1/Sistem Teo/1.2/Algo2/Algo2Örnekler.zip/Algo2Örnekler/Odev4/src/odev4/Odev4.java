package odev4;
import javax.swing.*;
import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Odev4 extends JApplet implements Runnable {
    public void init(){
        setSize(500,500);
                
    }
    public void paint(Graphics g){
        for (int i = 0; i < 5; i++) {
            g.setColor(Color.BLACK);
            g.drawString("SERHAN", 50, 50);
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
                Logger.getLogger(Odev4.class.getName()).log(Level.SEVERE, null, ex);
            }
            g.setColor(Color.WHITE);
            g.drawString("SERHAN", 50, 50);
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
                Logger.getLogger(Odev4.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            g.setColor(Color.BLACK);
            g.drawString("UÇAR",50,50);
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
                Logger.getLogger(Odev4.class.getName()).log(Level.SEVERE, null, ex);
            }
            g.setColor(Color.WHITE);
            g.drawString("UÇAR",50,50);
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
                Logger.getLogger(Odev4.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
    
    
    
    @Override
    public void run() {
        repaint();
    }

  
    
    
}
