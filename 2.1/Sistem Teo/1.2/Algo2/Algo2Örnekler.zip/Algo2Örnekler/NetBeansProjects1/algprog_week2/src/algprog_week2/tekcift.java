package algprog_week2;

import java.io.File;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PCLAB1-46
 */
public class tekcift {
    public void tekCıftoku(String path) {
        try {
            Scanner s = new Scanner(new File(path));
            int tektoplam = 0;
            int cifttoplam = 0;
            int teksayac = 0;
            int ciftsayac = 0;
            while (s.hasNext()) {
                int a = s.nextInt();
                if (a % 2 == 0) {
                    ciftsayac++;
                    cifttoplam += a;
                } else {
                    teksayac++;
                    tektoplam += a;
                }
            }
            System.out.println(
                    "TEK SAYI ADEDI  = " + teksayac
                    + "\nCIFT SAYI ADEDI = " + ciftsayac
                    + "\nTEK SAYILARIN TOPLAMI     = " + tektoplam
                    + "\nCIFT SAYILARIN TOPLAMI    = " + cifttoplam);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        tekcift tek_cift=new tekcift();
        tek_cift.tekCıftoku("D://sayi.txt");
    }
}
