package soru2;
class polinom{
    double[]katsayilar;
    int derece;
    polinom(double []kat){
       katsayilar=new double[kat.length];
       //katsayilar=kat;
        for (int i = 0; i < kat.length; i++) 
            katsayilar[i]=kat[i];
    }    
    void getDerece(){
     derece=-1;
        for (int i = katsayilar.length-1; i>=0; i--) {
            if(katsayilar[i]!=0) {derece=i; break;}            
        }}
    void goster(){
        String S="";
        for (int i = katsayilar.length-1;i>=0; i--) 
            if(katsayilar[i]!=0) 
                S=S+katsayilar[i]+"x^"+i+"+";            
        System.out.println(S);
    }
    double hesapla(double x){ 
    double top=0;
    for (int i = katsayilar.length-1;i>=0; i--) 
            if(katsayilar[i]!=0) 
                top=top+katsayilar[i]*Math.pow(x, i);            
        return top;}}
public class Soru2 {   
    public static void main(String[] args) {
        double []kat={1,2,2,0};
        polinom p=new polinom(kat);
        p.getDerece();
        p.goster();
        System.out.println(p.hesapla(2));
        System.out.println("Derece:"+p.derece);
    }
    
}
