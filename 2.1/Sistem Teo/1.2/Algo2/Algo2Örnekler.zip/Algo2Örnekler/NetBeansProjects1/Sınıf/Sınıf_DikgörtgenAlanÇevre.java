class dikdortgen {

    double w, h;

    dikdortgen() {
        w = 2;
        h = 1;
    }

    dikdortgen(double g, double y) {
        w = g;
        h = y;
    }

    double alanHesap() {
        return w * h;
    }

    double cevreHesap() {
        return 2 * w + 2 * h;
    }
}

public class Sınıf_DikgörtgenAlanÇevre {

    public static void main(String[] args) {
        dikdortgen d = new dikdortgen();
        System.out.println("Kenarlar:" + d.h + " " + d.w);
        System.out.println("Alan:" + d.alanHesap());
        System.out.println("Cevre:" + d.cevreHesap());
        dikdortgen d1 = new dikdortgen(3.2, 4.5);
        System.out.println("Kenarlar:" + d1.h + " " + d1.w);
        System.out.println("Alan:" + d1.alanHesap());
        System.out.println("Cevre:" + d1.cevreHesap());
    }
}
