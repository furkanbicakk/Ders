package dosyaislemleri;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class DosyaIslemleri {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        File klasor = new File("C:\\");
        
        File [] dosyalar = klasor.listFiles();
        for (int i = 0; i < dosyalar.length; i++) {
            System.out.println(dosyalar[i].getName());
        }
    }
}
