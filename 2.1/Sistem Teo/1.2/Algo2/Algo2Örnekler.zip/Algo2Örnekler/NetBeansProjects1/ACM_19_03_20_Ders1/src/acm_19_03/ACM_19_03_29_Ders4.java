package acm_19_03;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class ACM_19_03_29_Ders4 {
    static public File hesaplar= new File("hesaplar");
    public static Scanner veriGirisi;
    public static String girilenKullaniciAdi="";
    
    public static void main(String[] args) throws IOException {
        menu();
    
    }
    
    public static void menu () throws IOException{
        veriGirisi= new Scanner(System.in);
        System.out.println("Merhabalar Sistemimize Hoş Geldiniz");
        System.out.println("Yeni üyelik açmak için 1, Mevcut üyeliğe giriş yapmak için 2 giriniz");
        String secim= veriGirisi.nextLine();
        if (secim.equals("1")){//Yeni üyelik
            yeniKayit();
        }else if (secim.equals("2")){//Giris
            giris();
        }else{
            System.err.println("Yanlış bir seçim yaptınız \n");
            menu();
        }
    }
    public static void yeniKayit() throws IOException{
        PrintWriter kaydedici= null;
        try {
            kaydedici= new PrintWriter(new FileOutputStream(hesaplar, true));
        } catch (FileNotFoundException ex) {
            hesaplar.createNewFile();
            kaydedici= new PrintWriter(hesaplar);
          }
        
        veriGirisi= new Scanner(System.in);
        
        System.out.println("Kullanıcı Adınızı Girin");
        String kullaniciAdi= veriGirisi.nextLine();
        System.out.println("Şifrenizi Girin");
        String sifre= veriGirisi.nextLine();
        if (kullaniciEslestir(kullaniciAdi)){
            System.out.println("Bu isimde bir hesap mevcut başka bir isim deneyin");
            yeniKayit();
        }else{
            kaydedici.println(kullaniciAdi+"|"+sifre);
            System.out.println(kullaniciAdi+" İsimli Kayıt Başarı İle Oluşturuldu");
            kaydedici.close();
            menu();
        }
        
        System.out.println("Bir Hata Meydana Geldi!");
        kaydedici.close();
        menu();
    }
    
    public static void giris() throws FileNotFoundException, IOException{
        Boolean girisYapildiMi= false;
        System.out.println("Giriş Paneline Hoş Geldiniz");
        Scanner kontrol= new Scanner(hesaplar);
        
        System.out.println("Kullanıcı Adınızı Girin");
        girilenKullaniciAdi= veriGirisi.nextLine();
        System.out.println("Şifrenizi Girin");
        String girilenSifre= veriGirisi.nextLine();
        girisYapildiMi= kullaniciEslestir(girilenKullaniciAdi, girilenSifre);
        if (girisYapildiMi){
            kullaniciMenusu();
        }else{
            System.out.println("Hatalı Giriş Yapıldı");
            menu();
        }
        
    }
    public static Boolean kullaniciEslestir (String kullaniciAdi) throws FileNotFoundException{
        Scanner kontrol= new Scanner(hesaplar);
        String okunanSatir="";
        String okunanKullaniciAdi="";
        while(kontrol.hasNextLine()){
            okunanKullaniciAdi="";
            okunanSatir=kontrol.nextLine();
            for (int i = 0; i < okunanSatir.length(); i++) {
                if (okunanSatir.charAt(i)!= '|'){
                    okunanKullaniciAdi+=okunanSatir.charAt(i);
                }else{
                    break;
                }
            }

            if (okunanKullaniciAdi.equals(kullaniciAdi)){
                return true;
            }
        }
        return false;
    }
    public static Boolean kullaniciEslestir(String kullaniciAdi, String sifre) throws FileNotFoundException{
        Scanner kontrol= new Scanner(hesaplar);
        String okunanSatir="";
        String okunanKullaniciAdi="";
        String okunanSifre="";
        int sifreninBaslangici= 0;
        while(kontrol.hasNextLine()){
            okunanKullaniciAdi="";
            okunanSifre="";
            okunanSatir=kontrol.nextLine();
            for (int i = 0; i < okunanSatir.length(); i++) {
                if (okunanSatir.charAt(i)!= '|'){
                    okunanKullaniciAdi+=okunanSatir.charAt(i);
                }else{
                    sifreninBaslangici= i+1;
                    break;
                }
            }
            okunanSifre= okunanSatir.substring(sifreninBaslangici, okunanSatir.length());
            
            if (okunanKullaniciAdi.equals(kullaniciAdi) && okunanSifre.equals(sifre)){
                return true;
            }
        }
        return false;
    }
    
    public static String veriSifrele(String girilen){
        String sonuc="";
        for (int i = 0; i < girilen.length(); i++) {
            sonuc+= (char)(girilen.charAt(i)+5);
        }
        return sonuc;
    }
    public static String veriCoz(String girilen){
        String sonuc="";
        for (int i = 0; i < girilen.length(); i++) {
            sonuc+= (char)(girilen.charAt(i)-5);
        }
        
        return sonuc;
    }
    
    public static void kullaniciMenusu(){
        System.out.println("Hoşgeldiniz "+girilenKullaniciAdi);
        System.out.println("Arayüz Başlatılıyor...");
        System.exit(0);
    }
}
