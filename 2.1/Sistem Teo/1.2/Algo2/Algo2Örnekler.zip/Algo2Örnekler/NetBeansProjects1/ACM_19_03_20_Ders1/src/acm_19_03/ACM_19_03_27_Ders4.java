
package acm_19_03;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ACM_19_03_27_Ders4 {
    public static void main(String[] args) throws FileNotFoundException {
        File dosya= new File("ornek.txt");
        Scanner oku= new Scanner(dosya);
        int okunacakSatir=3;
        for (int i = 1; i < okunacakSatir; i++) {
            oku.nextLine();
            if(!oku.hasNextLine()){
                System.out.println("Dosyanın Satır Sayısı Aşıldı");
                break;
            }
        }
        System.out.println(oku.nextLine());
    }
}
