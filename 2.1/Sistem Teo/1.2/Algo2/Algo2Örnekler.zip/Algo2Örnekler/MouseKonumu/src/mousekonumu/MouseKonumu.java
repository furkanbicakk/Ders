package mousekonumu;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class MouseKonumu extends Applet implements MouseMotionListener{
    
    int mx,my;
    int secim;
    
    public void init()
    {
        setBackground(Color.WHITE);
        setSize(400,400);
        addMouseMotionListener(this);
    }
    
    public void paint(Graphics g)
    {
        if (secim == 1) 
        {
            g.setColor(Color.red);
        }
        
        else { g.setColor(Color.black); }
        
        g.drawString("Mouse Konumu: " + mx + "," + my, getWidth()/2,getHeight()/2);
    }

    @Override
    public void mouseDragged(MouseEvent e) 
    {
        secim = 1;
        mx = e.getX();
        my = e.getY();
        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) 
    {
       secim = 0;
       mx = e.getX();
       my = e.getY();
       repaint();
       
    }

 
    
}
