
package thread_ornek;

public class Tuketici extends Thread{
    private Paylasilan paylasilan;
    public Tuketici(Paylasilan paylasilan){
    super(" Tuketici");
    this.paylasilan=paylasilan;}

    
    public void run(){
    int deger, toplam=0;
    do{
        try{Thread.sleep((int)Math.random()*1000);}catch(InterruptedException ex){}
    deger=paylasilan.getpaylasilansayi();
    toplam+=deger;
    }while(deger!=10);
        System.out.println(this.getName() + " Tuketim bitti toplam alinan: "+ toplam);
    }
}
