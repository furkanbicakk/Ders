package siniflar;
import test.*;
public class testmatematik {
    public static void main(String[] args) {
        System.out.println(Matematik.PI);
        System.out.println(Matematik.e);
        System.out.println(Matematik.abs(-8));
        System.out.println(Matematik.pow(2, 4));
    }
}
