
package algprog_week2;

import java.io.File;
import java.util.Scanner;
public class isim_okuma {
    public void adSoyadOku(String path) {
        try {
            Scanner s = new Scanner(new File(path));
            while (s.hasNextLine()) {
                String satir = s.nextLine();
                String[] tokens = satir.split("\t");
                String ad = tokens[0];
                String soyad = tokens[1];
                System.out.println("Ad = " + ad + "\t Soyad= " + soyad);
            }
        } catch (Exception e) {
        }
    }
    public static void main(String[] args) {
        isim_okuma okuyucu=new isim_okuma();
        okuyucu.adSoyadOku("D:\\50isim.txt");
    }
}
