package acm_19_03;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

public class ACM_19_03_27_Ders2 {
    public static void main(String[] args) throws IOException{
        File dosya= new File("ornek.txt");
        if(!dosya.exists()){
            System.out.println("Dosya bulunamadı yeniden oluşturuluyor...");
            dosya.createNewFile();
        }
        
        PrintWriter kalem= new PrintWriter(new FileOutputStream(dosya, true));
        kalem.println("Furkan");
        kalem.close();

    }
}
