package acm_19_03;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ACM_19_03_27_Ders1 {
    static int girilen;
    public static void sayigirisi (){
        
        Scanner klavye= new Scanner(System.in);
        System.out.println("Bir sayı giriniz");        
        try{
            int girilen= klavye.nextInt();
        }catch(InputMismatchException e){
            System.out.println("Hata");
            sayigirisi();
        }
    }
    public static void sayigirisiT() throws InputMismatchException{
        Scanner klavye= new Scanner(System.in);
        System.out.println("Bir sayı giriniz"); 
        int girilen= klavye.nextInt();
    }
    
        public static void main(String[] args){
            sayigirisi();
        
        
    }
}
