
package thread_ornek;

public class Paylasilan {
private int paylasilansayi=-1;
private boolean uretilebilir=true;
public synchronized void setpaylasilan(int deger){
while(!uretilebilir){
try{wait();}catch(InterruptedException ex){
}
}
System.out.println(Thread.currentThread().getName()+ " uretildi "+ deger);
paylasilansayi=deger;
uretilebilir=false;
notify();
}
public synchronized int getpaylasilansayi(){
while(uretilebilir){
try{wait();}catch(InterruptedException ex){}
}
uretilebilir=true;
notify();
    System.out.println(Thread.currentThread().getName()+ " deger paylasimdan alindi "+ paylasilansayi);
return paylasilansayi;
}

    
  
    
}
