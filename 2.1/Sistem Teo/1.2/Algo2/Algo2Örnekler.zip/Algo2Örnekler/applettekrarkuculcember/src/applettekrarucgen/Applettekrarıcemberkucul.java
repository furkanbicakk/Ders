package applettekrarucgen;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Applettekrarıcemberkucul extends Applet{
    int a=200;
    int b=100;
    int secim=1;
    
    public void init()
    {
        setSize(500,500);
        setBackground(Color.red);
    }
    public void update()
    {
        if (secim==1) 
        {
            a++;
            b-=2;
            
            if (b==20) 
            {
                secim=2;
            }
        }
        
        if (secim == 2) 
        {
            a--;
            b+=2;
            if (b==100) 
            {
                secim=1;
            }
        }
        
        repaint();
        
        Thread.sleep(25);
        
    }
    
    public void paint(Graphics g)
    {
        g.drawOval(a, a, b, b);
        update();
    }

    
   
}
