
package thread_ornekler;

import java.util.logging.Level;
import java.util.logging.Logger;

public class UykuTest extends Thread {
    int i=0;
    public void run(){
        try{
        while(true){
            i++;
            System.out.println("uyuyor...");
            Thread.sleep(60*10);      
            if(i==5)
            {
                System.out.println("uyandı...");
                return;
            }
        }
        }catch(InterruptedException ex){
        }    
    }
    public static void main(String[] args) {
        UykuTest ut= new UykuTest();
        ut.start();
    }
}
