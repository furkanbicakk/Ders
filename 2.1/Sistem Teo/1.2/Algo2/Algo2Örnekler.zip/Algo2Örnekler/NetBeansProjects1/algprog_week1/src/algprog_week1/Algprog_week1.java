/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algprog_week1;

/**
 *
 * @author betul
 */
public class Algprog_week1 {

    public static void main(String[] args) {
        //motivation
        //key notes from previous term
        //What is the output of this program? 
        /*
        int array_variable [] = new int[10];
	    for (int i = 0; i < 10; ++i) {
                array_variable[i] = i;
                System.out.print(array_variable[i] + " ");
                i++;
            }
          */
    }
    
}
