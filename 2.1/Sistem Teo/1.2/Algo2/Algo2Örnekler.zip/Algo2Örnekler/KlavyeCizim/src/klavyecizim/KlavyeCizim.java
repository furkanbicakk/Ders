
package klavyecizim;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KlavyeCizim extends Applet implements KeyListener{
    
    int secim;
    char key;
    
    public void init()
    {
        setBackground(Color.red);
        setSize(300,300);
        addKeyListener(this);
    }

    public void paint(Graphics g)
    {
        if (secim==1) 
        {
            g.drawOval(30, 30, 50, 50);
        }
        
        else if(secim==2)
        {
            g.fill3DRect(30, 30, 50, 50, true);
        }
        
         else if(secim==3)
        {
            g.drawLine(20, 20, 60, 60);
        }
        
    }
    
    @Override
    public void keyPressed(KeyEvent e) 
    {
       key = e.getKeyChar();
       if(key== 'c'){ secim = 1;}
       if(key== 'a'){ secim = 2;}
       if(key== 'b'){ secim = 3;}
        repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    
}
