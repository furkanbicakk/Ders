package acm_19_03.ACM_19_04_03_Ders1;

public class OrnekConstructor {
    int x;
    public OrnekConstructor(String isim){
        x=10;
        System.out.println(isim+" String değişkeni tanımlanıldı");
    }
    public OrnekConstructor(){
        x=0;
        System.out.println("İçeriye bir parametre girilmedi");
    }
    public int toplamaYap(int a, int b){
        return a+b+x;
    }
    
}
