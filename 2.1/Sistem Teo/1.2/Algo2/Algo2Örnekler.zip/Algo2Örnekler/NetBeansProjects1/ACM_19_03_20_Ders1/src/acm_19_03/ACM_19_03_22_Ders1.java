package acm_19_03;


public class ACM_19_03_22_Ders1 {
    public static void main(String[] args) {
        int a= 5;
        System.out.println("Dairenin Çevresi");
        System.out.println(daireCevresi(a));
        System.out.println("Dairenin Alanı");
        System.out.println(daireAlani(a));
        System.out.println(faktoriyel(6));
    }
    
    public static double pi (){
        return 3.14;
    }
    
    public static double daireCevresi(int r){
        return 2*pi()*r;
    }
    
    public static double daireAlani(int r){
        return pi()*r*r;
    }
    
    public static int faktoriyel(int r){
        int toplam= 1;
        for (int i = 2; i < r; i++) {
            toplam*= i;
        }
        return toplam;
    }
    
    
}
