
package finahazırlık2;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;

public class silindir extends Applet{
    
    public void init()
    {
        setSize(300,300);
        setBackground(Color.MAGENTA);
    }
    
    public void paint(Graphics g)
    {
        g.drawOval(100, 100, 50, 15);    // üst çember
        g.drawLine(100, 108, 100, 200);  // yan çizgi1
        g.drawLine(150, 108, 150, 200); //yançizgi2
        g.drawOval(100, 192, 50, 15);
    }
}


