
package recursivefonksiyonlar;

import java.util.Scanner;

public class Fibonacci {

    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Bir sayı giriniz");
        int n=s.nextInt();
        int sonuc=fibonacci(n);
        System.out.println("Sonuç="+sonuc);
    }
    public static int fibonacci(int sayi)
    {
        if(sayi==0)
            return 0;
        else if (sayi==1)
            return 1;
        else 
            return fibonacci(sayi-1)+fibonacci(sayi-2); 
    }
    
}
