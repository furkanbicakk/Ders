package vizesinavi;

import java.io.File;
import java.util.Scanner;
public class soru5 {
    public static void main(String[] args) {
        Scanner oku=null;
        File dosya=new File("ali.txt");
        try {
            oku=new Scanner(dosya);
            while(oku.hasNext()){
                String okunan=oku.nextLine();
                 String []S=okunan.split(" ");
                 for (int i = 0; i < S.length; i++) {
                  if((S[i].charAt(0)>='a' && S[i].charAt(0)<='z')||
                    (S[i].charAt(0)>='A' && S[i].charAt(0)<='Z')) 
                         System.out.println(S[i]);                    
                }
            }
            oku.close();
        } catch (Exception e) {
        }
    }
}
