
package acm_19_03;


public class ACM_19_03_20_Ders1 {


    public static void main(String[] args) {
        System.out.println(Pi());
        double a= dairealani(5);
        System.out.println(a);
    }
    public static double Pi(){
        return 3.14;
    }
    public static double dairealani (int r){
        return Pi() * r * r;
    }
    public static double dairecevresi (int r){
        return 2 * Pi() * r;
    }
}
