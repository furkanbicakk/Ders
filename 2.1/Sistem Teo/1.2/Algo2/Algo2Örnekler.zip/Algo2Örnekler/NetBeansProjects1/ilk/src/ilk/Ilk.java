/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ilk;
import java.util.Scanner;
/**
 *
 * @author PCLAB1-46
 */
public class Ilk {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      int Dizim[]=new int[10];
      int toplam=0,en_B=0,en_K=0;
      Scanner oku=new Scanner(System.in);
      Dizim[0]=oku.nextInt();
      en_B=Dizim[0];
      en_K=Dizim[0];
      for(int i=1;i<10;i++){
          System.out.println(i+". elemanı giriniz;");    
      Dizim[i]=oku.nextInt();
      }
      for(int k=0;k<10;k++){
          System.out.println(k+". eleman"+Dizim[k]);
          toplam=toplam+Dizim[k];
           System.out.println("toplam="+toplam);
           if(en_B<Dizim[k]){
           en_B=Dizim[k];
           }
           
           if(en_K>Dizim[k]){
           en_K=Dizim[k];
           }
           
      }
        System.out.println("en büyük="+en_B);
       System.out.println("en küçük="+en_K);
    }
   
    }
    
}
