package finalhazırlık5;
//10sinx

import java.applet.Applet;
import java.awt.Graphics;

public class sinegrısı extends Applet {
    
    //10sin(x) eğrisi
    
    double x1,y1,x2,y2;
    double artis = 0.0001;
    
    public void paint(Graphics g)
    {
        for (double x = 0; x <= 2*3.14; x+=artis) 
        {
            x1=x;
            y1=10*Math.sin(x1);
            
            x2=x+artis;
            y2=10*Math.sin(x2);
            
            g.drawLine(100 + (int)(x1*5), 100 +(int)(y1*5), 100 +(int)(x2*5), 100 +(int)(y2*5));
        }
    }
    


    
}
