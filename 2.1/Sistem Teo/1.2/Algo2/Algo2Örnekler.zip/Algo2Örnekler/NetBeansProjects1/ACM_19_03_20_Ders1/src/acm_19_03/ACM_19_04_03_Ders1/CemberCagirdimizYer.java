package acm_19_03.ACM_19_04_03_Ders1;

public class CemberCagirdimizYer {
    public static void main(String[] args) {
        Cember cember1= new Cember();
        Cember cember2= new Cember(25);
        Cember cember3= new Cember(125);
        System.out.println(cember1.alan());
        System.out.println(cember2.alan());
        System.out.println(cember3.alan());
    }
}
