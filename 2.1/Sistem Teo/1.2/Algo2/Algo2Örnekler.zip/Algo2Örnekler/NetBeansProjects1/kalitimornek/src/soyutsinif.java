abstract class Body{
    public double yogunluk;
    public Body(double y){yogunluk=y;}
    public double getYogunluk(){ return yogunluk;} 
    public double getKutle(){ return yogunluk*getHacim();}    
    public abstract double getHacim();}
class Kup extends Body{
 double kenar;
   Kup(double kenar, double y){ super(y);this.kenar=kenar;}
    @Override
    public double getHacim() {return kenar*kenar*kenar;}    
}
public class soyutsinif {
    public static void main(String[] args) {
        Kup k=new Kup(4, 3);
        System.out.println("Kütle:"+k.getKutle());
        System.out.println("Hacim:"+k.getHacim());
        System.out.println("Yoğunluk:"+k.getYogunluk());
    }
}
