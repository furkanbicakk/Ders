/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algprog_week1;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

/**
 *
 * @author betul
 */
public class person {
    public String firstName;
    public String lastName;
    public Calendar birthday;
    
    public String fullName()
    {
        return firstName + " " + lastName;
    }
    
    public int age(Calendar today)
    {
        return today.get(Calendar.YEAR) - birthday.get(Calendar.YEAR);
    }
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        person john = new person();
        john.firstName = "John";
        john.lastName = "Doe";
        john.birthday = new GregorianCalendar(1988,1,5);
        System.out.println(john.fullName());
        System.out.println(john.age(new GregorianCalendar()));
}
}
