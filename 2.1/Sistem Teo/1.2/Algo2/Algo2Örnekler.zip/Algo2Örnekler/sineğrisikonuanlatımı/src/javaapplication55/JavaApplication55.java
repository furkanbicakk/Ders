package javaapplication55;

import java.applet.Applet;
import java.awt.Graphics;


public class JavaApplication55 extends Applet
{
    double x1, x2, y1, y2;
    double artis = 0.0001;
    
    public void paint(Graphics g)
    {
        for (double x = 0; x <= 2*3.14; x += artis) //0'dan 2 PI'ye kadar... Artış miktarı ne kadar küçük olursa o kadar detaylı çizer.
        {
            x1 = x;  // İlk noktayı x olarak aldım
            y1 = 10 * Math.sin(x1); // İlk noktaya göre fonksiyonun sonucunu buldum
            
            x2 = x + artis; // İkinci nokta x'ten artış mesafesi kadar uzakta
            y2 = 10 * Math.sin(x2); // İkinci noktaya göre  fonksiyonun sonucunu buldum
            
            /* 
                (x1,y1)'den (x2,y2)'ye çizgi çektim. Her döngüde çizilen çizgiler birbirlerine ekleniyor görüntüde.
                Değerlerin başında 100 ile toplamamın sebebi (100,100) noktasından çizmeye başlaması için
                5 ile çarpmamın sebebi ekranda görünmesi için yoksa küçük oluyor.
            */
            g.drawLine(100 + (int)(5*x1), 100 + (int)(5*y1), 100 + (int)(5*x2), 100 + (int)(5*y2));
        }
    }
    
}
