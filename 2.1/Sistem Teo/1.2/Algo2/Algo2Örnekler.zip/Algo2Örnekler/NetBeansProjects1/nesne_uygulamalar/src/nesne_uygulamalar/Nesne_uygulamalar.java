package nesne_uygulamalar;
class nokta{
    private double x,y;
    public nokta(){ this(0,0);   }
    public nokta(double x, double y) {
        this.x = x;
        this.y = y;}
    public double getx(){return x;}
    public double gety(){return y;}
    public void setx(double x){this.x=x;}
    public void sety(double y){this.y=y;}
    public double mesafe(nokta p){
        double mes=(this.x-p.x)*(this.x-p.x)+(this.y-p.y)*(this.y-p.y);
        mes=Math.sqrt(mes);
        return mes;
    }
    public void goster(){
         System.out.println(x+" "+y);
    }
}
public class Nesne_uygulamalar {
    public static void main(String[] args) {
     nokta p1=new nokta(2,4);
       p1.goster();
     nokta p2=new nokta();
       p2.goster();
        System.out.println(p1.mesafe(p2));
        p2.setx(2.3);
        p2.sety(3.8);
        p2.goster(); 
    }
    
}
