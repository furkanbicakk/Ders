 interface madde{
    public double getHacim();
    public double getYogunluk();
    public double getKutle();}
 class kup implements madde{
     public double kenar=1.0,yogunluk=1.0;
    @Override
    public double getHacim() { return kenar*kenar*kenar;}
    @Override
    public double getYogunluk() { return yogunluk;}
    @Override
    public double getKutle() { return yogunluk*getHacim();   }     
 }
public class arayuzUygulama {
    public static void main(String[] args) {
        kup k=new kup();
        System.out.println(k.getHacim()+" "+k.getKutle()+" "
                +k.getYogunluk());
    }
}
