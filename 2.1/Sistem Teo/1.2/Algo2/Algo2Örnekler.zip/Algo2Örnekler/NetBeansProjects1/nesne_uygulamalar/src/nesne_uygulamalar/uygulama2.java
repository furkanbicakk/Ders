package nesne_uygulamalar;
 class ogrenci{
     static int no=0;
     int v,f;
    public ogrenci(int v,int f){ no++;
        this.f=f;
        this.v=v;}
    public double ort(){ return Math.round(v*0.4+f*0.6); }
    public String gecme(){
        if(ort()>=50) return "Geçti";
        else return "Kaldı"; }
    public void goster(){
        System.out.println(no+"\t"+v+"\t"+f+
                "\t"+ort()+"\t"+gecme());
    }
 }
public class uygulama2 {
    public static void main(String[] args) {
        ogrenci [] ogr=new ogrenci[10];
        for(int j=0;j<ogr.length;j++){
            int vize=(int)(Math.random()*100);
            int genel=(int)(Math.random()*100);
            ogr[j]=new ogrenci(vize,genel);
          // ogr[j].goster();
            System.out.println(ogrenci.no+" "+ogr[j].v+" "+ogr[j].f);
            System.out.println(ogr[j].gecme());
        }
    }
}
