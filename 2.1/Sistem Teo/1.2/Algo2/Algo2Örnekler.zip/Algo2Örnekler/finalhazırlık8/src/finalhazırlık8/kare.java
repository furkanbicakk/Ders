package finalhazırlık8;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;

public class kare extends Applet {
    
    public void init()
    {
        setSize(500,500);
        setBackground(Color.red);
    }
    
    public void paint(Graphics g)
    {
        g.drawLine(50,50,50,100);
        g.drawLine(50,50,200,50);
        g.drawLine(50,100,200,100);
        g.drawLine(200,50,200,100);
    }


    
}
