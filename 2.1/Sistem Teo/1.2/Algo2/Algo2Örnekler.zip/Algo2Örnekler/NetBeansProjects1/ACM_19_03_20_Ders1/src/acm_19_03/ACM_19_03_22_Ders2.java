package acm_19_03;

public class ACM_19_03_22_Ders2 {
    public static void main(String[] args) {
        int dizi[] = new int[100];
        dizi= rastgeleElemanAta(dizi);
        cakismaVarmi(dizi, 5);
    }
    
    public static int[] rastgeleElemanAta(int[] atanacakDizi){
        for(int i=0; i < atanacakDizi.length; i++){
            atanacakDizi[i]= (int)(Math.random()*10);
            System.out.println(atanacakDizi[i]);
        }
        return atanacakDizi;
    }
    
    public static void cakismaVarmi(int[] aranacakDizi, int girilen){
        for (int i = 0; i < aranacakDizi.length; i++) {
            if (aranacakDizi[i] == girilen){
                System.out.println("Çakışma Var");
                break;
            }
        }
    }
    
    
    
}
