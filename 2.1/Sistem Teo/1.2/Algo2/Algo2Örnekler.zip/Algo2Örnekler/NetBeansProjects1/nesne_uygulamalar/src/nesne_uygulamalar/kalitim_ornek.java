package nesne_uygulamalar;

import java.util.Scanner;
class temelsinif{
    int a,b;
    public void verigetir(){
        Scanner klavye=new Scanner(System.in);
        System.out.println("a ve b değerini gir");
        a=klavye.nextInt();
        b=klavye.nextInt();}
    public void yazdir(){System.out.println(a+" "+b);}}
class toplama extends  temelsinif{
    public int topla(){   return a+b;  }
}
public class kalitim_ornek {
    public static void main(String[] args) {
        toplama t=new toplama();
        t.verigetir();
        t.yazdir();
        System.out.println("toplam:"+t.topla());
                
    }
}
