package acm_19_03;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ACM_19_03_29_Ders1 {
    public static void main(String[] args) {
        Scanner k= new Scanner(System.in);
        
        System.out.println("Bir Sayı Girin");
        try{
            int girilen= k.nextInt();
        }catch (InputMismatchException hata){
            System.out.println("Hatalı Giriş Yapıldı");
            main(args);
        }
        
    }
}
