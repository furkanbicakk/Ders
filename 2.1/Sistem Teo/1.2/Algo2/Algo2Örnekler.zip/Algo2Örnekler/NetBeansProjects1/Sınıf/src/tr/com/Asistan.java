package tr.com;
import tr.edu.*;
public class Asistan {
  public void arastir() {
	System.out.println("Asistan arastiriyor");
  }
  public void kullan() {
	//Robot upuaut = new Robot(); Hata! erişemez
  }
    public static void main(String[] args) {
       // Robot upuaut = new Robot(); 
    }
}
