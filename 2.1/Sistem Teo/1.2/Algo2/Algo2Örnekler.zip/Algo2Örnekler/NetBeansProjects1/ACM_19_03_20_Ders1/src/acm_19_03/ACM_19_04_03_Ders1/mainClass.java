package acm_19_03.ACM_19_04_03_Ders1;
public class mainClass {
    public static void main(String[] args) {
        OrnekConstructor a= new OrnekConstructor("Furkan");
        OrnekConstructor b= new OrnekConstructor();
        System.out.println(a.toplamaYap(0, 5));
        System.out.println(b.toplamaYap(0, 5));
    }
}
