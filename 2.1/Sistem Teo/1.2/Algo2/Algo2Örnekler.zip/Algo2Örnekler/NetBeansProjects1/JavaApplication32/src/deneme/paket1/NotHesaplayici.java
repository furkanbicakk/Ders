package deneme.paket1;

import java.util.Scanner;

class NotHesaplayici extends SatirIslemci implements DosyaIslemci {

    @Override
    public String satirIsle(String cumle) {
        Scanner s = new Scanner(cumle);
        String no = s.next();
        double vize1 = s.nextDouble();
        double vize2 = s.nextDouble();
        double ort = (vize1 + vize2)/2;
        String yeniCumle = no + "\t" +vize1 + "\t" + vize2 + "\t" + ort + "\n";
        return yeniCumle;
    }

    @Override
    public void dosyaOku(String dosyaAdi) {
        try {
            Scanner s = new Scanner(new File(dosyaAdi));
            String yeniDosyaIcerigi = "";
            while(s.hasNext()){
                String satir = s.nextLine();
                yeniDosyaIcerigi += satirIsle(satir);
            }
  
        } catch (Exception e) {
        }
    }

    @Override
    public void dosyayaYaz(String adi, String dosyaIcerigi) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
