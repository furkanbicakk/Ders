package soru2;

import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;
interface dosyaListe{void dosyaListele(File f);}
abstract class dosyaokuyaz{
abstract void dosyayaz(File dosya,ogrenci[]ogr);
abstract void dosyaOku(File f);}
class ogrenci{
    int numara,notu;
    String isim;
    public ogrenci(int numara, int notu, String isim) {
        this.numara = numara;
        this.notu = notu;
        this.isim = isim;}}
public class Soru1 extends dosyaokuyaz implements dosyaListe{
    @Override
    void dosyayaz(File dosya, ogrenci[] ogr) {
        try {
            PrintWriter p=new PrintWriter(dosya);
            for (int i = 0; i < ogr.length; i++) 
                p.print(ogr[i].isim+" "+ogr[i].numara+" "+
                        ogr[i].notu+"\n");                
            p.close();
        } catch (Exception e) {
        }
    }
    @Override
    void dosyaOku(File f) {
        try { Scanner oku=new Scanner(f);
            int top=0,sayac=0;
            while(oku.hasNext()){
                int num=oku.nextInt();
                String isim=oku.next();
                int notu=oku.nextInt();
                top+=notu;
                sayac++;}
            oku.close();
            System.out.println("Sınıf ortalaması:"+
                    (top/sayac));
        } catch (Exception e) {        }    }

    @Override
    public void dosyaListele(File f) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
