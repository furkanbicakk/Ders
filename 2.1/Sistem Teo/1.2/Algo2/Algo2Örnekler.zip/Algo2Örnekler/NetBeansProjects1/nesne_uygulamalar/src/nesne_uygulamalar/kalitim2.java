package nesne_uygulamalar;
class student {
    student(){ this("Merhaba");
        System.out.println("Öğrenci kurucu metodu"); }
    student (String isim){ System.out.println(isim); }    
}
class undergraduate extends student{
    public undergraduate() {      
        System.out.println("Lisans öğrenci kurucu metodu");        
    }}
class graduate extends undergraduate{
    public graduate(){ 
        System.out.println("Yüksek Lisans kurucu metodu"); }}
public class kalitim2 {
    public static void main(String[] args) {
        graduate g=new graduate();
    }
}
