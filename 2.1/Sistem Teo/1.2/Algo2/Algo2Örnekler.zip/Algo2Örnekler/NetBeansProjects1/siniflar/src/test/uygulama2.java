package test;
class rasyonel{
    int pay,payda;
    public rasyonel(int py,int pyd) {
        pay=py;
        payda=pyd; }
    void goster(){ System.out.println(pay+"/"+payda);}
    static int obeb(int a,int b){
        int kucuk;
        if(a>=b) kucuk=b; else kucuk=a;
        for (int i = kucuk; i >1; i--) 
            if(a%i==0 && b%i==0) return i;        
        return 1;
    }
    void sadelestir(){
        int sonuc=obeb(pay, payda);
        pay=pay/sonuc;
        payda=payda/sonuc;
    }
}
public class uygulama2 {
    public static void main(String[] args) {
        rasyonel r1=new rasyonel(8, 12);
        r1.goster();
        r1.sadelestir();
        r1.goster();
        System.out.println(rasyonel.obeb(5, 10));
        
    }
}
