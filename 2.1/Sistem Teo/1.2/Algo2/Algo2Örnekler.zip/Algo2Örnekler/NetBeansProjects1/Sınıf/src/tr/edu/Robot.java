package tr.edu;
public class Robot {
 
  int calisma_sure = 0;
  String renk = "beyaz";
  int motor_gucu = 120;
 
  Robot() {
	System.out.println("Robot olusturuluyor");
  }
}
