package deneme.paket1;

public interface DosyaIslemci {
//public class DosyaIslemci {
    
    //public void dosyaOku(String adi){   }
    public void dosyaOku(String dosyAdi);
    public void dosyayaYaz(String adi, String dosyaIcerigi);
    
}

abstract class SatirIslemci{
    public abstract String satirIsle(String satir);
}
