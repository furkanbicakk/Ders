/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algoritmalab_week2;
public class kedi {
   public int cansayisi;
    public String gozrengi;
    public kedi(){
    cansayisi=9;
    gozrengi="mavi";
    }
    public void seslenme(){
        System.out.println("miyav");
    }
    public void beslenme(){
    System.out.println("fare yerim");
    }
    public static void main(String[] args) {
        kedi tekir=new kedi();
        tekir.beslenme();
        tekir.seslenme();
    } 
}
