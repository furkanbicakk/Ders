package tr.edu;
 
public class Hayvan {
	protected String a = "Hayvan.a";
	String b = "Hayvan.b"; //friendly
	private String c = "Hayvan.c";
	public String d = "Hayvan.d"; ;
}
