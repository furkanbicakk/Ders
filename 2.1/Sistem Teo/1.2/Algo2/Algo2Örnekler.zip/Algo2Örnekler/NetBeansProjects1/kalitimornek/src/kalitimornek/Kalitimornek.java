package kalitimornek;
class bisiklet 
{   public int vites,hiz;
    public bisiklet(int vites, int hiz)
    {  this.vites = vites;
        this.hiz = hiz;}
    public void frenyap(int azalt)  {   hiz -= azalt;   }         
    public void hizlan(int arttir) {hiz += arttir;    }   
    public String toString() 
    { return "Vites Sayısı: "+vites+"\n Hız: "+hiz; } 
} 
class DagBisikleti extends bisiklet{
  public int kyukseklik;
    public DagBisikleti(int vites,int hiz,int ilkyukseklik){
        super(vites, hiz);// bisiklet sınıfı kurucu metodu çağrılıyor
        kyukseklik = ilkyukseklik; }       
    public void setHeight(int yeni)    { kyukseklik = yeni; } 
     @Override
    public String toString() { return (super.toString()+
            "\n koltuk yuksekligi "+kyukseklik); }     }
public class Kalitimornek {
    public static void main(String args[]){        
        DagBisikleti mb = new DagBisikleti(3, 100, 25);
        bisiklet b=new bisiklet(4, 30);
        System.out.println(b.toString());
        System.out.println(mb);  }
}


