
package recursivefonksiyonlar;

public class BasamakBulma {
    public static void main(String[] args) {
        System.out.println("Basamak Sayısı="+BasamakSayisi(0));
    }
    public static int BasamakSayisi(int n)
    {
        if (n<10)
            return 1;
        else 
            return 1+BasamakSayisi(n/10);
    }
}
