package javaapplication1;

import java.util.Scanner;

public class JavaApplication1 {
    public static void main(String[] args) {
        int []dizi1=new int[10];
        for (int i = 0; i < dizi1.length; i++) {
            dizi1[i]=(int)(Math.random()*100);
        }
        
        int []dizi2=new int[10];
        Scanner k=new Scanner(System.in);
        for (int i = 0; i < dizi2.length; i++) {
            dizi2[i]=k.nextInt();
        }
        for (int i = 0; i < dizi1.length; i++) {
            System.out.print(" "+dizi1[i]);
        }
        System.out.println("");
        
        for (int i = 0; i < dizi2.length; i++) {
            System.out.print(" "+dizi2[i]);
        }
        System.out.println("");
        
        int []ikidizi=new int[dizi1.length+dizi2.length];
        ikidizi=birlestir(dizi1, dizi2);
        for (int i = 0; i < ikidizi.length; i++) {
            System.out.print(" "+ikidizi[i]);
        }
        System.out.println("");
    }
    public static int[] birlestir(int []di1, int []di2){
        int []db=new int[di1.length+di2.length];
        for (int i = 0; i < db.length; i++) {
            if(i<di1.length)
                db[i]=di1[i];
            else
                db[i]=di2[i-di1.length];
        }
        return db;
    }
}
