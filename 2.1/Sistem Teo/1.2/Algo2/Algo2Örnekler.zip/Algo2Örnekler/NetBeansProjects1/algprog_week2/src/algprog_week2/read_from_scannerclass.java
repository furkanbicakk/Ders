
package algprog_week2;
import java.io.*;
import java.util.Scanner;
public class read_from_scannerclass {
    public static void main(String[] args) throws FileNotFoundException {
    File file =new File("C:\\Users\\PCLAB1-46\\Desktop\\haber.txt");
    Scanner sc = new Scanner(file);
    while (sc.hasNextLine())
      System.out.println(sc.nextLine());
    }
}
