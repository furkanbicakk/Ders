
package applettekrar;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;


public class Applettekrar extends Applet{
    
    double x1,y1,x2,y2;
    double artis =0.0001;
    
    public void init()
    {
        setSize(700,700);
        setBackground(Color.red);
    }
    
    public void paint(Graphics g)
    {
        for (double x = 0; x <= 2*3.14; x+=artis) 
        {
            x1=x;
            y1= 4+10*Math.sin(x1);
            
            x2=x+artis;
            y2=4+10*Math.sin(x2);
            
            g.drawLine(100+(int)(x1*5), 100+(int)(y1*5), 100+(int)(x2*5), 100+(int)(y2*5));
        }
    }
    
 
    
}
