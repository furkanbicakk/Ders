
package algoritmalab_week2;

public class AlgoritmaLab_week2 {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
