/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ilkprojem;
import java.util.Scanner;
/**
 *
 * @author PCLAB1-46
 */
public class Ilkprojem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String kelime="Bilgisayar Mühendisliği";
        String cümle="fırat Üniversitesi Mühendislik Fakültesi  Bilgisayar Mühendisliği";
        int baslangıc=0;
        System.out.println("3.boşluk"+cümle.indexOf(" ", 3));
        for(int i=0;i<cümle.length();i++){
           
        if(' '==cümle.charAt(i)){
            System.out.println(cümle.substring(baslangıc, i));
        baslangıc=i;
        }
        }
        
        System.out.println("g harfi kaçıncı sırada"+ kelime.indexOf("g"));
        System.out.println("2. i harfi kaçıncı sırada"+kelime.indexOf(" ", 2));
        System.out.println("Bilgisayar kelimesi kaçıncı sırada="+cümle.indexOf("Bilgisayar"));
        for(int i=0;i<kelime.length();i++){
            System.out.println(i+"eleman="+kelime.charAt(i));
        }        
        System.out.println(kelime.toUpperCase());
        System.out.println(kelime.toLowerCase());
        System.out.println(cümle.replace("Mühendislik", "Teknoloji"));
        System.out.println("cümlenin son yarısı"+kelime.substring(10));
        
        int sayi=3;
        String yenisayi=String.valueOf(sayi);//stringe çevirme
        String sayikelime="10254";
        int yenisayim=Integer.parseInt(sayikelime);//sayi çevirme
        System.out.println("Toplam="+toplam(10));
       System.out.println("faktoriyel="+faktoriyel(10));
    }
    public static int toplam(int sayi){
    if(sayi==1){
    return 1;
    }else{
    return sayi+toplam(sayi-1);
    }
    
    }
    public static int faktoriyel(int sayi){
    if(sayi==1){
    return 1;
    }else{
    return sayi*faktoriyel(sayi-1);
    }
    }
}
