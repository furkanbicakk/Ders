
public class Balik extends Hayvan {

    @Override
    public void solunum() { System.out.println("Balıklar Solungaç "
            + "Solunumu Yapar"); }
    
    public void sudaYuzer() { System.out.println("Balıklar suda yüzer");}

    public static void main(String[] args) {
        Balik b1 = new Balik();
        b1.solunum();  //genel olarak hayvanlardan farklı özellik
        b1.sudaYuzer(); //hayvanda olmayan yeni özellik
        b1.boyut();
    }
}
