class ucgen{double kenar1,kenar2,kenar3;
    ucgen(){kenar1=1.0;kenar2=1.0;kenar3=1.0;}
    ucgen(double kenar1,double kenar2,double kenar3){
        this.kenar1=kenar1;this.kenar2=kenar2; this.kenar3=kenar3;}
    double getAlan(){
        double u=getcevre()/2;
        return Math.sqrt(u*(u-kenar1)*(u-kenar2)*(u-kenar3));}    
double getcevre(){return kenar1+kenar2+kenar3;}
public String toString(){
    return "Üçgenin alanı:"+getAlan()+" çevresi:"+getcevre();}}
public class kornek4 {
    public static void main(String[] args) {
    ucgen u=new ucgen(3,4,5);
        System.out.println(u.toString());
    }
    
}
