
public class Hayvan {

    public void beslenme() { System.out.println("Hayvanlar Beslenir");}

    public void barinma() { System.out.println("Hayvanlar Barınır");}

    public void diski() {  System.out.println("Hayvanlar Dışkı Bırakır");}

    public void boyut() { System.out.println("Hayvanları Boyutları Vardır");}

    public void solunum() { System.out.println("Hayvanları Solunum Yapar");}

}
