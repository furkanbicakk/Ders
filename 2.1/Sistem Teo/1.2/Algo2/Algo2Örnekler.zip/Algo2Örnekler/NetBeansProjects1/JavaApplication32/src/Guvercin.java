
public class Guvercin extends Kus {
    
}
