package kalitimornek;
class ebeveyn{
    void goster() { System.out.println("Ebeveyn"); }}
class cocuk extends ebeveyn{
    @Override
    void goster() { 
        System.out.println("Çocuk"); }}
class kornek3{
    public static void main(String[] args)    {
       ebeveyn obj1 = new ebeveyn();  obj1.goster();
        ebeveyn obj2 = new cocuk();    obj2.goster();
    }}

