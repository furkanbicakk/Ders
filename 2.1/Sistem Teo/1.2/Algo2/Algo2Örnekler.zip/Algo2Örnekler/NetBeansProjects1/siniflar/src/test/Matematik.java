package test;
public class Matematik {
 public final static double PI=3.14;
 public final static double e=2.71;
 public static int abs(int a){
     if(a>0) return a;
     else return -1*a;
 }
 public static int pow(int a,int b){
     int us=1;
     for (int i = 1; i <=b; i++) 
         us=us*a;
     return us;     
 }
    
}
