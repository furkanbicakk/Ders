package javaapplication33;
public class JavaApplication33 { 
    public static void main(String[] args) {
        m(new YuksekLisansOgrencisi());
        m(new Ogrenci());
        m(new Kisi());
        m(new Object());
    }
    public static void m(Object x) {
        System.out.println(x.toString());
    }
 }

    class YuksekLisansOgrencisi extends Ogrenci{ }
    class Ogrenci extends Kisi {
        
        public String toString() {
            return "Ogrenci";
        }
        
    }
    class Kisi extends Object {
        public String toString() {
            return "Kişi";
        }
    }
