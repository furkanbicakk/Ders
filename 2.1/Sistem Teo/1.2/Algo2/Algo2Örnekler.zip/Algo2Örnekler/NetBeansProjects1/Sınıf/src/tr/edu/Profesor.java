package tr.edu;
 
class Profesor { 
 public void kullan() {
	Robot upuaut = new Robot(); // sorunsuz
 }
    public static void main(String[] args) {
        Robot upuaut = new Robot(); // sorunsuz
    }
}
