/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package benimilkproje;
import java.util.Scanner;//klavyede veri al
/**
 *
 * @author PCLAB1-46
 */
public class Benimilkporoje {
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("metni giriniz:");
       int sayac_a=0,sayac_e=0,sayac_i=0;
        int sayac_ı=0,sayac_o=0,sayac_ö=0;
        int sayac_ü=0,sayac_u=0;
       Scanner oku=new Scanner(System.in);
        String n=oku.nextLine();
        for(int i=0;i<n.length();i++){
            System.out.println(n.charAt(i));
            if(n.charAt(i)=='a'){
            sayac_a++;
            }
             if(n.charAt(i)=='e'){
            sayac_e++;
            }
              if(n.charAt(i)=='i'){
            sayac_i++;
            }
        }
        System.out.println("e harfi:"+sayac_e);
        System.out.println("a harfi:"+sayac_a);
    }
    
}
