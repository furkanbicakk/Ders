
package thread_ornek;

public class Test {
    public static void main(String[] args) {
        Paylasilan py=new Paylasilan();
        Uretici uret=new Uretici(py);
        Tuketici tuket=new Tuketici(py);
        uret.start();
        tuket.start();
        
    }
}
