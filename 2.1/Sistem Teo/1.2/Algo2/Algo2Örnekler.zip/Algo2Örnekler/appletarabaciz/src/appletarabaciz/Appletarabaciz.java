package appletarabaciz;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;

public class Appletarabaciz extends Applet {
    
 public void init()
    {
        setSize(500,500);
        setBackground(Color.red);
    }
   public void paint(Graphics g)
   {
       g.drawLine(10, 10, 10, 50);
       g.drawLine(10, 10, 80, 10);
       g.drawLine(10, 50, 80, 50);
       g.drawLine(80, 10, 80, 50);
       
       g.drawOval(20, 50, 10, 10);
       g.drawOval(60, 50, 10, 10);
       
   }
   
    
}
