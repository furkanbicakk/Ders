
public class JaponBaligi extends Balik {
    
    public void solunum(){
        super.solunum();
    }
    
}
