/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thread_ornekler;

class Robot7 extends Thread{
    private Robot5 r5;
    public Robot7(String isim,Robot5 r5)
    {
        super(isim);
        this.r5=r5;
    }
    public void run()
    {
        try {
            System.out.println(this.getName()+" beklemeye başlıyor...");
            r5.join();
            for (int i = 0; i < 5; i++) {
                System.out.println(this.getName()+"<->"+i);
            }            
        } catch (Exception e) {
        }
    }
}
class Robot5 extends Thread{
    public Robot5(String isim){
        super(isim);
    } 
    public void run(){
        for (int i = 0; i < 6; i++) {
            System.out.println(this.getName()+"<->"+i);
        }
    }
}

public class Thread_Ornekler {
    public static void main(String[] args) {
        Robot5 r5=new Robot5("Robot5");
        Robot7 r7=new Robot7("Robot7",r5);
        r7.start();
        r5.start();
    }   
}
