package uygulama;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class Uygulama extends JFrame{
  JButton b1,b2;
  JTextField t1,t2;
  JPanel p1;
  public Uygulama(){
      b1=new JButton("OK");
      b2=new JButton("İPTAL");
      t1=new JTextField(5);t2=new JTextField(5);
      p1=new JPanel();p1.add(t1);p1.add(t2);
      p1.add(b1);p1.add(b2);add(p1);
      b1.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
              int s1=Integer.parseInt(t1.getText());
              int s2=Integer.parseInt(t2.getText());
                 JOptionPane.showMessageDialog(rootPane, 
                         "Sonuç="+(s1+s2)); } });
  }  
    public static void main(String[] args) {
        Uygulama u=new Uygulama();
        u.setTitle("Ilk Uygulama");
        u.setDefaultCloseOperation(EXIT_ON_CLOSE);
        u.setSize(200, 200);
        u.setVisible(true);
    }
    
}
