package acm_19_03;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ACM_19_03_29_Ders3 {
    public static void main(String[] args) {
        
        File ornekDosya= new File("Ornek.txt");
        Scanner oku = null;
        try {
           oku = new Scanner(ornekDosya);
        } catch (FileNotFoundException ex) {
            System.err.println("Dosya bulunamadı program kapatılıyor");
            System.exit(0);
        }
        while(oku.hasNextLine()){
            System.out.println(oku.nextLine());
        }
        
        
    }
}
