/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algprog_week1;

/**
 *
 * @author betul
 */
public class methods_ex1 {
public static void main(String[] args) {
int x = 5;
magic(x);
System.out.println("main: " + x);
    System.out.println(magic(x));
}
public static int magic(int input)
{
input += 10;
//System.out.println("input = " + input);
return input;
}
}
