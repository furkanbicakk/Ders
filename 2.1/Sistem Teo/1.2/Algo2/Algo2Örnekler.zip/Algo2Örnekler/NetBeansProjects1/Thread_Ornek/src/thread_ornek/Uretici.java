package thread_ornek;
public class Uretici extends Thread{
    private Paylasilan paylasilan;
    public Uretici(Paylasilan paylasilan){
        super(" Uretici");
        this.paylasilan=paylasilan;
    }

   
    public void run(){
    for(int i=1; i<=10; i++){
    try{Thread.sleep(1000);}catch(InterruptedException ex){}
    paylasilan.setpaylasilan(i);
    }
        System.out.println(this.getName()+ " uretim bitti ");   
    }   
}
