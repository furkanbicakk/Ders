package nesne_uygulamalar;
class kitap{
    public int sayfasayisi(){ return 100; }
    public double hamfiyat(){return 60;}
}
class roman extends kitap{
    public int fiyatogren(){     return 100;  }
    @Override
    public int sayfasayisi(){ return 1000;}
}
class hikaye extends kitap{
    public double hamfiyat(){return super.hamfiyat()*0.9;}
}
public class kalitim3 {
    public static void main(String[] args) {
        hikaye h=new hikaye();
        System.out.println(h.hamfiyat());
        System.out.println(h.sayfasayisi());
        roman r=new roman();
        System.out.println(r.fiyatogren());
        System.out.println(r.sayfasayisi());
    }
}
