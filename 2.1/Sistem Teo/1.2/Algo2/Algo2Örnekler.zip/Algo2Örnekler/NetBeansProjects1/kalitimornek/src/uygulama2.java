class adres{
    String mahalle,sokak,sehir;
    int no,pkodu;
    adres(String mahalle,String sokak,String sehir, int no, int pkodu){
        this.mahalle=mahalle;this.sehir=sehir;this.sokak=sokak;
        this.pkodu=pkodu;this.no=no;
    }
public String toString(){
        return "["+mahalle+","+sokak+","+no+","+pkodu+","+sehir+"]";}
}
class ogrenci{
    String numara,isim;
    adres adr;
    double v,g;
    ogrenci(String numara,String isim,adres adr,double v,double g){
        this.numara=numara; this.adr=adr;
        this.isim=isim;this.g=g;this.v=v;        
    }
    public String toString(){
        return numara+"-"+isim+"-"+(v*0.4+g*0.6)+adr;
    }}
public class uygulama2 {
    public static void main(String[] args) {
        adres adr=new adres("Çaydaçıra Mah.", "Deneme",
                "Elazığ", 70, 23119);
        ogrenci o=new ogrenci("15260001", "Ayşe", adr, 50, 75);
        System.out.println(o); }}
