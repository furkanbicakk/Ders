package devtamsayi;


public class DevTamsayi {
    
    
    
    
    public void dev_sayigiris()
    {
        DevTamsayi dev_sayi = new DevTamsayi();
        System.out.println("boş dev tam sayı= " + dev_sayi);
    }
    
    public void dev_sayicikis()
    {
        
    }

    public void esittir()
    {
        
    }
    
    public void topla()
    {
        
    }
    
    public void cikar()
    {
        
    }
    
    
    public static void main(String[] args) {
        
    }
    
}
