package dosyaokumasplit;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Dosyaokumasplit {

    public static void main(String[] args) throws FileNotFoundException 
    {
        File not = new File("ali.txt");
        File sonuc = new File("sonuc.txt");
        PrintWriter pw = new PrintWriter(sonuc);
        Scanner oku = new Scanner(not);
        
        int v,f;
        double s;
        String gk ="";
        
        while (oku.hasNext()) 
        {            
            String satir = oku.next();
            String [] dizi = satir.split(",");
            
            v=Integer.parseInt(dizi[0]);
            f=Integer.parseInt(dizi[1]);
            s=v*0.4+f*0.6;
            
            if (f>=50 && s>=50) 
            {
                gk = "Gectiniz";
            }
            
            else if (f<50 && s<50) 
            {
                gk = "Kaldınız";
            }
            
            pw.println("sonuc: " + s + gk);
            
        }
        
        pw.close();
        
        
    }
}
