package javaapplication3;

interface buzustundekayabilme
{ 
   public void buzustundekay() ;
}

interface sutatabilme
{
public void sutat() ;
}

class SportmenMehmet implements buzustundekayabilme,sutatabilme
{
    
@Override
public void sutat(){}
@Override
public void buzustundekay() {}

}

public class JavaApplication3 {
     
    public static void main(String[] args) {
        
        SportmenMehmet x = new SportmenMehmet();
        x.buzustundekay();
        x.sutat();
        
    }
    
}
