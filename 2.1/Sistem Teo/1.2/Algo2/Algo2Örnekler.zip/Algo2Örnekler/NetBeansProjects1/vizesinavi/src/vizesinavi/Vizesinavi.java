package vizesinavi;
public class Vizesinavi {
    public static int rakamtopla(int x){
        if(x>=-9 && x<=9) return x;
        else return (x%10)+rakamtopla(x/10);
    }
    
    
    public static void main(String[] args) {
        System.out.println(rakamtopla(82367));
    }
    
}
