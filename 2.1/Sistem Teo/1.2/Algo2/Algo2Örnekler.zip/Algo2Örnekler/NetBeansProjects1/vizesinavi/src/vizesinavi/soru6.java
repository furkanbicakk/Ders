package vizesinavi;
public class soru6 {
    static String dondur(String [][] S){
        String dondurulen="";
        for (int i = 0; i < S.length; i++) 
            for (int j = 0; j < S[i].length; j++) 
                if(S[i][j].length()==5)
                    dondurulen=dondurulen+" "+S[i][j];
        return dondurulen;                
    }
}
