
package algprog_week2;
import java.io.*;

public class read_from_bufferreader {
    // We need to provide file path as the parameter:
  // double backquote is to avoid compiler interpret words
  // like \test as \t (ie. as a escape sequence)
  public static void main(String[] args) throws FileNotFoundException, IOException {
  File file = new File("D:\\haber.txt");
  BufferedReader br = new BufferedReader(new FileReader(file));
  String st;
  while((st = br.readLine()) != null)
    System.out.println(st);
    }
  
}
