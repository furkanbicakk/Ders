
package algoritma_lab1;
/**
 *
 * @author PCLAB1-46
 */
public class kedi {
    public int cansayisi;
    public String gozrengi;
    public kedi(){
    cansayisi=9;
    gozrengi="yesil";
    }
    public void seslenme(){
        System.out.println("miyavv");
    }
    public void beslenme(){
        System.out.println("fare yerim");
    }
    public static void main(String[] args) {
        kedi tekir=new kedi();
        tekir.beslenme();
        //tekir.seslenme();
        System.out.println(tekir.cansayisi);
    }
    
}
