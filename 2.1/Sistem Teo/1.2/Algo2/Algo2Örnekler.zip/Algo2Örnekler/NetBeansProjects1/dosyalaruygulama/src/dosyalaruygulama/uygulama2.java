package dosyalaruygulama;
import java.io.*;
import java.util.Scanner;
public class uygulama2 {
    public static void main(String[] args) {
        File dosya=new File("ogrenci.txt");
        File yaz=new File("sonuc.txt");
        PrintWriter p=null;
        Scanner oku=null;
        try {
            if(dosya.exists())
            {
                oku=new Scanner(dosya);
                if(!yaz.exists()) yaz.createNewFile();
                
                p=new PrintWriter(new FileOutputStream(yaz, false));
                
                while(oku.hasNext())
                {
                    String satir=oku.nextLine();
                    String []okunan=satir.split(",");
                    int v=Integer.parseInt(okunan[2]);
                    int f=Integer.parseInt(okunan[3]);
                    double ort=v*0.4+f*0.6;
                    p.println(okunan[0]+","+okunan[1]+","+ort);
                }  p.close(); oku.close();
            }
            
        } catch (Exception e) {
        }
    }
    
}
