package algprog_week2;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
public class read_from_scannerclass2 {
    public static void main(String[] args) {
        try {
          File file = new File("D:\\haber.txt");
          Scanner sc;  sc = new Scanner(file);
          sc.useDelimiter("\\Z");
          System.out.println(sc.next());
        } catch (FileNotFoundException ex) {
            System.out.println(ex);
        }
    
    }
    
}
