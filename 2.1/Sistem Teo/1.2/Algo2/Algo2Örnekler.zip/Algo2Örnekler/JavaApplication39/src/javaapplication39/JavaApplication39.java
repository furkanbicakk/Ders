package javaapplication39;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class JavaApplication39 {

    public static void main(String[] args) throws FileNotFoundException {
        
        
       File f = new File("C:\\Users\\PCLAB1-46\\Desktop\\cocukisimleri.txt");
       Scanner k = new Scanner(f);
       Scanner klavye = new Scanner(System.in);
       String aranan = klavye.nextLine();
       aranan += ",";
       String[] dizi = new String[7];
       k.nextLine();
       int toplam = 0;
       int enb=0;
       String isim="";
       while(k.hasNextLine()){
           
           /*if (k.next().equals(aranan)) {
               for (int i = 0; i < 6; i++) {
                   System.out.print(k.next()+" ");
               }
           }*/
           
           dizi = k.nextLine().split(",");
           
           for (int i = 1; i < dizi.length; i++) {
               toplam+= Integer.parseInt(dizi[i].trim());
           }
           if (toplam>enb) {
               enb=toplam;
               isim = dizi[0];
           }
           toplam = 0;
           
           
       }
        
       k.close();
        System.out.println();
        System.out.println("En cok tekrar eden isim: "+isim+"/ ne kadar tekrar etti : "+enb);
        
    }
    
}
