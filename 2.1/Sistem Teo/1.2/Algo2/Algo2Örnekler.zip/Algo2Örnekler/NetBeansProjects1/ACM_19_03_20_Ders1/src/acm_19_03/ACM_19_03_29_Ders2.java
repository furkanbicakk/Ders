package acm_19_03;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

public class ACM_19_03_29_Ders2 {
    public static void main(String[] args) throws IOException {
        File ornekDosya = new File("ornek.txt");
        if(!ornekDosya.exists()){
            System.out.println("Dosya Mevcut Değil Yeniden Oluşturuluyor");
            ornekDosya.createNewFile();
        }
        PrintWriter kalem= new PrintWriter(new FileOutputStream(ornekDosya, true));
        for (int i = 1; i < 5; i++) {
            kalem.println("Furkan "+i);
        }
        kalem.close();
    }
}
