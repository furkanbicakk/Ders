package dosyalaruygulama;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;
public class Dosyalaruygulama {
    public static void main(String[] args) {
        PrintWriter p=null;
        File dosya=new File("ogrenci.txt");
        Scanner klavye=new Scanner(System.in);
        try { if(!dosya.exists()) dosya.createNewFile();
            p=new PrintWriter(new FileOutputStream(dosya, true));
            System.out.println("Öğrencinin adı soyadı vize final notu:");
            String ad=klavye.next();
            String soyad=klavye.next();
            int vize=klavye.nextInt();
            int genel=klavye.nextInt();
            p.println(ad+","+soyad+","+vize+","+genel);}
        catch (Exception e) {    }
        p.close();
        
    }
    
}
