
package acm_19_03;

import java.util.Scanner;

public class ACM_19_03_20_Ders2 {
    public static void main(String[] args) {
        Scanner klavye = new Scanner(System.in);
    }
}
