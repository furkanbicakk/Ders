package finalhazırlık7;

import java.applet.Applet;
import java.awt.Graphics;

public class Finalhazırlık7 extends Applet {

    public void paint(Graphics g)
    {
        g.drawLine(50, 50, 130, 50);
        g.drawString("Furkan Bıçak", 62, 62);
        g.drawLine(50, 65, 130, 65);
        g.drawLine(50, 50, 50, 65);
        g.drawLine(130, 50, 130, 65);
    }
 
    
}
