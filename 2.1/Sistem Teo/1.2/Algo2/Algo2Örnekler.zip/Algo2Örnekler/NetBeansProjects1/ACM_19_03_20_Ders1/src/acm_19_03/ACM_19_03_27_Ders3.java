
package acm_19_03;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ACM_19_03_27_Ders3 {
    public static void main(String[] args) throws FileNotFoundException {
        File dosya= new File("ornek.txt");
        Scanner oku= new Scanner(dosya);
        while (oku.hasNextLine()){
            System.out.println(oku.nextLine());
        }
        oku.close();
    }
}
