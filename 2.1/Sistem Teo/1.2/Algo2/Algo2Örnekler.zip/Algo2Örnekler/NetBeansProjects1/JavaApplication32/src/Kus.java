public class Kus extends Hayvan {
    //overwrite
    // beslenme
    // boyut
}
