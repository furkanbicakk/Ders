
package algo_diziler;
import java.util.Random;
import java.util.Scanner;
public class Algo_diziler {

    public static void main(String[] args) {
        int A[][]=new int [3][3]; int B[][]= new int[3][3];
        int C[][]=new int [3][3];
        Random r=new Random();
        int dizi[][]={{1,2,3,4,5},{1,2,0,4,5},{1,0,0,0,5},{1,2,0,4,5},{1,2,3,4,5}};
        Scanner k=new Scanner(System.in);
        for(int i=0; i<dizi.length; i++){
            for(int j=0; j<dizi[i].length; j++){
                if(dizi[i][j]==0) System.out.print("  ");
                else System.out.print(dizi[i][j]+" ");
            } System.out.println("");
        }

    }
    }  
